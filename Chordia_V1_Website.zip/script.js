
function showSection(id){
 document.querySelectorAll('.section').forEach(s=>s.classList.add('hidden'));
 document.getElementById(id).classList.remove('hidden');
}
let lang='en';
function toggleLang(){
 lang = lang==='en' ? 'es' : 'en';
 alert(lang==='es' ? 'Idioma cambiado a Español' : 'Language changed to English');
}
