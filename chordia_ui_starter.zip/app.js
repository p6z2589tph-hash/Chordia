const colorPicker = document.getElementById("colorPicker");

colorPicker.addEventListener("input", (e) => {
  document.documentElement.style.setProperty("--accent", e.target.value);
});
