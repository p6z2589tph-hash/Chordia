Chordia UI Starter Kit

Includes:
- Theme color picker
- Basic UI layout
- Logo placeholder (replace logo.png with your own)
- Signature styling for "de Niko Gonzalez"

Next upgrades you can add:
- Saved themes (localStorage)
- Login system
- Dashboard pages
- Animated UI transitions
